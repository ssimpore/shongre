import { Market, MarketConfiguration } from './market.types';

/**
 * Canonical French Baseline Configuration (The Immutable Reference Standard)
 */
export const FR_CANONICAL_CONFIG: MarketConfiguration = {
  general: {
    name: 'France Métropolitaine',
    tagline: 'La référence des annonces sécurisées et de la seconde main',
    supportEmail: 'support@shongre.fr',
    supportPhone: '+33 1 89 20 40 00',
    launchState: 'full',
  },
  localization: {
    defaultLocale: 'fr-FR',
    supportedLocales: ['fr-FR', 'en-US'],
    defaultCurrency: 'EUR',
    currencySymbol: '€',
    timezone: 'Europe/Paris',
    dateFormat: 'dd/MM/yyyy',
    dateTimeFormat: 'dd/MM/yyyy HH:mm',
    phonePrefix: '+33',
    phonePlaceholder: '06 12 34 56 78',
    phoneRegex: '^(?:(?:\\+|00)33|0)[1-9](?:[\\s.-]*\\d{2}){4}$',
    postalCodePlaceholder: '75001',
    postalCodeRegex: '^[0-9]{5}$',
  },
  listings: {
    maxActiveListingsIndividual: 20,
    maxActiveListingsProFree: 20,
    maxPhotosIndividual: 8,
    maxPhotosPro: 20,
    expirationDays: 60,
    allowFreeDonations: true,
    allowPriceNegotiation: true,
    allowInstantBuy: true,
  },
  payments: {
    enabled: true,
    provider: 'mangopay_escrow',
    supportedMethods: {
      card: true,
      applePay: true,
      googlePay: true,
      sepa: true,
    },
    buyerProtectionFeePercent: 0.04, // 4%
    buyerProtectionFixedFee: 0.70, // 0.70 €
    minTransactionAmount: 1,
    maxTransactionAmount: 15000,
  },
  reservation: {
    enabled: true,
    sellerConfirmationTimeoutHours: 48,
    buyerInspectionTimeoutHours: 48,
    autoCompleteDays: 3,
    requirePinForHandDelivery: true,
  },
  delivery: {
    enabled: true,
    handDeliveryEnabled: true,
    carriers: {
      mondialRelay: {
        enabled: true,
        label: 'Mondial Relay (Point Relais)',
        defaultFee: 4.90,
        trackingSupported: true,
      },
      colissimo: {
        enabled: true,
        label: 'Colissimo Domicile',
        defaultFee: 6.90,
        trackingSupported: true,
      },
      chronopost: {
        enabled: true,
        label: 'Chronopost Express 24h',
        defaultFee: 12.90,
        trackingSupported: true,
      },
      customCarrier: {
        enabled: false,
        label: 'Transporteur sur devis',
        defaultFee: 25.00,
        trackingSupported: false,
      },
    },
  },
  monetization: {
    proCommissionRate: 0.03, // 3%
    individualCommissionRate: 0.00, // 0%
    payoutInstantFeePercent: 0.01, // 1%
    payoutInstantFixedFee: 0.50, // 0.50 €
    boostPricing: {
      urgent: 4.90,
      highlight: 7.90,
      top_of_list: 3.90,
      gallery_boost: 6.90,
      spotlight: 9.90,
    },
    plans: {
      free: {
        priceMonthly: 0,
        maxActiveListings: 20,
        photosPerListing: 8,
        storefrontCustomization: false,
        prioritySupport: false,
        bulkImportExport: false,
        automaticRelisting: false,
      },
      starter: {
        priceMonthly: 19.90,
        maxActiveListings: 100,
        photosPerListing: 15,
        storefrontCustomization: true,
        prioritySupport: false,
        bulkImportExport: false,
        automaticRelisting: true,
      },
      business: {
        priceMonthly: 49.90,
        maxActiveListings: 500,
        photosPerListing: 20,
        storefrontCustomization: true,
        prioritySupport: true,
        bulkImportExport: true,
        automaticRelisting: true,
      },
      enterprise: {
        priceMonthly: 129.90,
        maxActiveListings: 2500,
        photosPerListing: 25,
        storefrontCustomization: true,
        prioritySupport: true,
        bulkImportExport: true,
        automaticRelisting: true,
      },
    },
  },
  pro: {
    businessIdentifierLabel: 'Numéro SIRET (ou SIREN)',
    businessIdentifierHelper: '14 chiffres pour le SIRET (ou 9 chiffres pour le SIREN). Ex : 849 204 892 00018',
    businessIdentifierRegex: '^(?:\\d{9}|\\d{14}|\\d{3}\\s\\d{3}\\s\\d{3}(?:\\s\\d{5})?)$',
    businessIdentifierFormatPlaceholder: '849 204 892 00018',
    secondaryIdentifierLabel: 'Code NAF / APE',
    vatNumberFormatPlaceholder: 'FR 84 849204892',
    vatNumberRegex: '^FR\\s?[0-9A-Z]{2}\\s?[0-9]{9}$',
    supportedLegalForms: [
      'Micro-entreprise / Auto-entrepreneur',
      'SAS / SASU',
      'SARL / EURL',
      'EI / EIRL',
      'SA',
      'Association loi 1901',
      'Autre statut professionnel',
    ],
    requiredVerificationDocuments: [
      {
        id: 'kbis',
        label: 'Extrait Kbis ou Avis SIRENE (INSEE)',
        description: 'Datant de moins de 3 mois certifiant l\'immatriculation au RCS ou RM',
      },
      {
        id: 'id_rep',
        label: 'Pièce d\'identité du représentant légal',
        description: 'CNI recto-verso ou passeport en cours de validité',
      },
    ],
    requireKbis: true,
  },
  taxes: {
    taxEnabled: true,
    vatRateStandard: 0.20, // 20%
    pricesTaxInclusive: true,
  },
  legal: {
    termsUrl: '/cgu',
    privacyUrl: '/confidentialite',
    cookiePolicyUrl: '/cookies',
    buyerProtectionTermsUrl: '/protection-acheteurs',
    proTermsUrl: '/conditions-pro',
    requiresLocalReview: false,
  },
  features: {
    reviewsEnabled: true,
    aiAssistantEnabled: true,
    aiSafetyAuditEnabled: true,
    savedSearchesEnabled: true,
    sellerFollowEnabled: true,
    proStorefrontsEnabled: true,
    disputeEscalationEnabled: true,
  },
  taxonomy: {
    disabledCategorySlugs: [],
    disabledSubCategorySlugs: [],
  },
};

/**
 * Initial Seed Markets Setup
 */
export const INITIAL_MARKETS: Market[] = [
  // 1. FRANCE (Reference Market - Exactly one default)
  {
    id: 'market-fr',
    code: 'FR',
    countryCode: 'FR',
    name: 'France',
    flag: '🇫🇷',
    status: 'active',
    isDefault: true,
    defaultLocale: 'fr-FR',
    supportedLocales: ['fr-FR', 'en-US'],
    currency: 'EUR',
    currencySymbol: '€',
    timezone: 'Europe/Paris',
    geography: {
      allCountryEnabled: true,
      regions: [
        {
          name: 'Île-de-France',
          code: 'IDF',
          cities: [
            { name: 'Paris', postalCode: '75000', region: 'Île-de-France', isPopular: true },
            { name: 'Boulogne-Billancourt', postalCode: '92100', region: 'Île-de-France', isPopular: true },
            { name: 'Saint-Denis', postalCode: '93200', region: 'Île-de-France' },
            { name: 'Versailles', postalCode: '78000', region: 'Île-de-France' },
          ],
        },
        {
          name: 'Auvergne-Rhône-Alpes',
          code: 'ARA',
          cities: [
            { name: 'Lyon', postalCode: '69000', region: 'Auvergne-Rhône-Alpes', isPopular: true },
            { name: 'Grenoble', postalCode: '38000', region: 'Auvergne-Rhône-Alpes', isPopular: true },
            { name: 'Saint-Étienne', postalCode: '42000', region: 'Auvergne-Rhône-Alpes' },
            { name: 'Annecy', postalCode: '74000', region: 'Auvergne-Rhône-Alpes' },
          ],
        },
        {
          name: 'Provence-Alpes-Côte d\'Azur',
          code: 'PACA',
          cities: [
            { name: 'Marseille', postalCode: '13000', region: 'Provence-Alpes-Côte d\'Azur', isPopular: true },
            { name: 'Nice', postalCode: '06000', region: 'Provence-Alpes-Côte d\'Azur', isPopular: true },
            { name: 'Toulon', postalCode: '83000', region: 'Provence-Alpes-Côte d\'Azur' },
            { name: 'Aix-en-Provence', postalCode: '13100', region: 'Provence-Alpes-Côte d\'Azur' },
          ],
        },
        {
          name: 'Nouvelle-Aquitaine',
          code: 'NAQ',
          cities: [
            { name: 'Bordeaux', postalCode: '33000', region: 'Nouvelle-Aquitaine', isPopular: true },
            { name: 'Limoges', postalCode: '87000', region: 'Nouvelle-Aquitaine' },
            { name: 'Poitiers', postalCode: '86000', region: 'Nouvelle-Aquitaine' },
          ],
        },
        {
          name: 'Occitanie',
          code: 'OCC',
          cities: [
            { name: 'Toulouse', postalCode: '31000', region: 'Occitanie', isPopular: true },
            { name: 'Montpellier', postalCode: '34000', region: 'Occitanie', isPopular: true },
            { name: 'Nîmes', postalCode: '30000', region: 'Occitanie' },
          ],
        },
        {
          name: 'Hauts-de-France',
          code: 'HDF',
          cities: [
            { name: 'Lille', postalCode: '59000', region: 'Hauts-de-France', isPopular: true },
            { name: 'Amiens', postalCode: '80000', region: 'Hauts-de-France' },
            { name: 'Roubaix', postalCode: '59100', region: 'Hauts-de-France' },
          ],
        },
      ],
      popularCities: [
        { name: 'Paris', postalCode: '75000', department: '75 - Paris', region: 'Île-de-France' },
        { name: 'Lyon', postalCode: '69000', department: '69 - Rhône', region: 'Auvergne-Rhône-Alpes' },
        { name: 'Marseille', postalCode: '13000', department: '13 - Bouches-du-Rhône', region: 'Provence-Alpes-Côte d\'Azur' },
        { name: 'Toulouse', postalCode: '31000', department: '31 - Haute-Garonne', region: 'Occitanie' },
        { name: 'Bordeaux', postalCode: '33000', department: '33 - Gironde', region: 'Nouvelle-Aquitaine' },
        { name: 'Nantes', postalCode: '44000', department: '44 - Loire-Atlantique', region: 'Pays de la Loire' },
        { name: 'Lille', postalCode: '59000', department: '59 - Nord', region: 'Hauts-de-France' },
        { name: 'Strasbourg', postalCode: '67000', department: '67 - Bas-Rhin', region: 'Grand Est' },
        { name: 'Rennes', postalCode: '35000', department: '35 - Ille-et-Vilaine', region: 'Bretagne' },
        { name: 'Nice', postalCode: '06000', department: '06 - Alpes-Maritimes', region: 'Provence-Alpes-Côte d\'Azur' },
        { name: 'Montpellier', postalCode: '34000', department: '34 - Hérault', region: 'Occitanie' },
      ],
    },
    overrides: {}, // France has 0 overrides because it is the canonical baseline itself
    createdAt: '2023-01-01T00:00:00Z',
    updatedAt: '2026-08-16T22:00:00Z',
    version: 1,
  },

  // 2. BELGIUM (Active - 92% Inherited from France with local BCE & VAT overrides)
  {
    id: 'market-be',
    code: 'BE',
    countryCode: 'BE',
    name: 'Belgique',
    flag: '🇧🇪',
    status: 'active',
    isDefault: false,
    defaultLocale: 'fr-BE',
    supportedLocales: ['fr-BE', 'nl-BE', 'en-US'],
    currency: 'EUR',
    currencySymbol: '€',
    timezone: 'Europe/Brussels',
    geography: {
      allCountryEnabled: true,
      regions: [
        {
          name: 'Région de Bruxelles-Capitale',
          code: 'BRU',
          cities: [
            { name: 'Bruxelles', postalCode: '1000', region: 'Bruxelles-Capitale', isPopular: true },
            { name: 'Ixelles', postalCode: '1050', region: 'Bruxelles-Capitale', isPopular: true },
            { name: 'Schaerbeek', postalCode: '1030', region: 'Bruxelles-Capitale' },
            { name: 'Uccle', postalCode: '1180', region: 'Bruxelles-Capitale' },
          ],
        },
        {
          name: 'Wallonie',
          code: 'WAL',
          cities: [
            { name: 'Liège', postalCode: '4000', region: 'Wallonie', isPopular: true },
            { name: 'Namur', postalCode: '5000', region: 'Wallonie', isPopular: true },
            { name: 'Charleroi', postalCode: '6000', region: 'Wallonie', isPopular: true },
            { name: 'Mons', postalCode: '7000', region: 'Wallonie' },
          ],
        },
        {
          name: 'Flandre',
          code: 'VLG',
          cities: [
            { name: 'Anvers (Antwerpen)', postalCode: '2000', region: 'Flandre', isPopular: true },
            { name: 'Gand (Gent)', postalCode: '9000', region: 'Flandre', isPopular: true },
            { name: 'Bruges (Brugge)', postalCode: '8000', region: 'Flandre' },
            { name: 'Louvain (Leuven)', postalCode: '3000', region: 'Flandre' },
          ],
        },
      ],
      popularCities: [
        { name: 'Bruxelles', postalCode: '1000', region: 'Bruxelles-Capitale' },
        { name: 'Liège', postalCode: '4000', region: 'Wallonie' },
        { name: 'Namur', postalCode: '5000', region: 'Wallonie' },
        { name: 'Anvers', postalCode: '2000', region: 'Flandre' },
        { name: 'Gand', postalCode: '9000', region: 'Flandre' },
        { name: 'Charleroi', postalCode: '6000', region: 'Wallonie' },
      ],
    },
    overrides: {
      general: {
        name: 'Belgique (Wallonie & Flandre)',
        supportEmail: 'support@shongre.be',
      },
      localization: {
        defaultLocale: 'fr-BE',
        supportedLocales: ['fr-BE', 'nl-BE', 'en-US'],
        phonePrefix: '+32',
        phonePlaceholder: '0470 12 34 56',
        phoneRegex: '^(?:(?:\\+|00)32|0)[1-9]\\d{7,8}$',
        postalCodePlaceholder: '1000',
        postalCodeRegex: '^[1-9][0-9]{3}$',
      },
      taxes: {
        vatRateStandard: 0.21, // 21% Belgian VAT
      },
      payments: {
        buyerProtectionFixedFee: 0.80, // 0.80 €
        buyerProtectionFeePercent: 0.045, // 4.5%
      },
      pro: {
        businessIdentifierLabel: 'Numéro d\'entreprise (BCE / KBO)',
        businessIdentifierHelper: '10 chiffres. Ex : 0849.204.892',
        businessIdentifierRegex: '^(?:BE\\s?)?0?\\d{9,10}$',
        businessIdentifierFormatPlaceholder: '0849.204.892',
        vatNumberFormatPlaceholder: 'BE 0849.204.892',
        vatNumberRegex: '^BE\\s?0?\\d{9,10}$',
        supportedLegalForms: [
          'Indépendant à titre principal / complémentaire',
          'SRL (Société à Responsabilité Limitée)',
          'SA (Société Anonyme)',
          'SC (Société Coopérative)',
          'ASBL',
        ],
        requiredVerificationDocuments: [
          {
            id: 'bce_extract',
            label: 'Extrait Banque-Carrefour des Entreprises (BCE)',
            description: 'Attestation officielle récente certifiant l\'inscription',
          },
        ],
      },
    },
    createdAt: '2023-06-15T00:00:00Z',
    updatedAt: '2026-08-16T22:00:00Z',
    version: 1,
  },

  // 3. SPAIN (Coming Soon / Draft - Overrides reservation: disabled as explicit false test)
  {
    id: 'market-es',
    code: 'ES',
    countryCode: 'ES',
    name: 'Espagne',
    flag: '🇪🇸',
    status: 'coming_soon',
    isDefault: false,
    defaultLocale: 'es-ES',
    supportedLocales: ['es-ES', 'en-US'],
    currency: 'EUR',
    currencySymbol: '€',
    timezone: 'Europe/Madrid',
    geography: {
      allCountryEnabled: true,
      regions: [
        {
          name: 'Comunidad de Madrid',
          code: 'MAD',
          cities: [
            { name: 'Madrid', postalCode: '28001', region: 'Comunidad de Madrid', isPopular: true },
            { name: 'Móstoles', postalCode: '28931', region: 'Comunidad de Madrid' },
          ],
        },
        {
          name: 'Cataluña',
          code: 'CAT',
          cities: [
            { name: 'Barcelona', postalCode: '08001', region: 'Cataluña', isPopular: true },
            { name: 'Hospitalet de Llobregat', postalCode: '08901', region: 'Cataluña' },
          ],
        },
        {
          name: 'Andalucía',
          code: 'AND',
          cities: [
            { name: 'Sevilla', postalCode: '41001', region: 'Andalucía', isPopular: true },
            { name: 'Málaga', postalCode: '29001', region: 'Andalucía', isPopular: true },
          ],
        },
      ],
      popularCities: [
        { name: 'Madrid', postalCode: '28001', region: 'Comunidad de Madrid' },
        { name: 'Barcelona', postalCode: '08001', region: 'Cataluña' },
        { name: 'Valencia', postalCode: '46001', region: 'Comunidad Valenciana' },
        { name: 'Sevilla', postalCode: '41001', region: 'Andalucía' },
        { name: 'Málaga', postalCode: '29001', region: 'Andalucía' },
      ],
    },
    overrides: {
      general: {
        name: 'Espagne (Península Ibérica)',
        supportEmail: 'soporte@shongre.es',
      },
      localization: {
        defaultLocale: 'es-ES',
        supportedLocales: ['es-ES', 'en-US'],
        phonePrefix: '+34',
        phonePlaceholder: '612 34 56 78',
        phoneRegex: '^(?:(?:\\+|00)34|0)?[6789]\\d{8}$',
        postalCodePlaceholder: '28001',
        postalCodeRegex: '^[0-9]{5}$',
      },
      taxes: {
        vatRateStandard: 0.21,
      },
      reservation: {
        enabled: false, // Explicit false: tests that false does NOT fall back to true
      },
      pro: {
        businessIdentifierLabel: 'Número CIF / NIF / NIE',
        businessIdentifierHelper: 'Format CIF (ex: B12345678) ou NIF',
        businessIdentifierRegex: '^[A-HJ-NP-SUVW]\\d{7}[0-9A-J]$',
        businessIdentifierFormatPlaceholder: 'B-12345678',
        vatNumberFormatPlaceholder: 'ES B12345678',
        vatNumberRegex: '^ES[A-HJ-NP-SUVW0-9]\\d{7}[0-9A-J]$',
        supportedLegalForms: [
          'Autónomo / Trabajador por cuenta propia',
          'SL (Sociedad Limitada)',
          'SA (Sociedad Anónima)',
          'Comunidad de Bienes',
        ],
        requiredVerificationDocuments: [
          {
            id: 'cif_extract',
            label: 'Tarjeta acreditativa del NIF (Agencia Tributaria)',
            description: 'Documento expedido por la AEAT',
          },
        ],
      },
    },
    createdAt: '2024-01-10T00:00:00Z',
    updatedAt: '2026-08-16T22:00:00Z',
    version: 1,
  },

  // 4. SWITZERLAND (Paused - Custom currency CHF, VAT 8.1%, IDE identifier)
  {
    id: 'market-ch',
    code: 'CH',
    countryCode: 'CH',
    name: 'Suisse',
    flag: '🇨🇭',
    status: 'paused',
    isDefault: false,
    defaultLocale: 'fr-CH',
    supportedLocales: ['fr-CH', 'de-CH', 'it-CH', 'en-US'],
    currency: 'CHF',
    currencySymbol: 'CHF',
    timezone: 'Europe/Zurich',
    geography: {
      allCountryEnabled: true,
      regions: [
        {
          name: 'Genève',
          code: 'GE',
          cities: [
            { name: 'Genève', postalCode: '1200', region: 'Genève', isPopular: true },
            { name: 'Vernier', postalCode: '1214', region: 'Genève' },
          ],
        },
        {
          name: 'Vaud',
          code: 'VD',
          cities: [
            { name: 'Lausanne', postalCode: '1000', region: 'Vaud', isPopular: true },
            { name: 'Montreux', postalCode: '1820', region: 'Vaud' },
          ],
        },
        {
          name: 'Zürich',
          code: 'ZH',
          cities: [
            { name: 'Zürich', postalCode: '8000', region: 'Zürich', isPopular: true },
            { name: 'Winterthur', postalCode: '8400', region: 'Zürich' },
          ],
        },
      ],
      popularCities: [
        { name: 'Genève', postalCode: '1200', region: 'Genève' },
        { name: 'Lausanne', postalCode: '1000', region: 'Vaud' },
        { name: 'Zürich', postalCode: '8000', region: 'Zürich' },
        { name: 'Bâle', postalCode: '4000', region: 'Bâle' },
        { name: 'Berne', postalCode: '3000', region: 'Berne' },
      ],
    },
    overrides: {
      general: {
        name: 'Suisse (Confédération Helvétique)',
        supportEmail: 'support@shongre.ch',
      },
      localization: {
        defaultLocale: 'fr-CH',
        supportedLocales: ['fr-CH', 'de-CH', 'it-CH', 'en-US'],
        defaultCurrency: 'CHF',
        currencySymbol: 'CHF',
        timezone: 'Europe/Zurich',
        phonePrefix: '+41',
        phonePlaceholder: '079 123 45 67',
        phoneRegex: '^(?:(?:\\+|00)41|0)[1-9]\\d{8}$',
        postalCodePlaceholder: '1201',
        postalCodeRegex: '^[1-9][0-9]{3}$',
      },
      payments: {
        buyerProtectionFixedFee: 1.00, // 1.00 CHF
        buyerProtectionFeePercent: 0.035, // 3.5%
      },
      taxes: {
        vatRateStandard: 0.081, // 8.1% Swiss VAT
      },
      pro: {
        businessIdentifierLabel: 'Numéro IDE / UID',
        businessIdentifierHelper: 'Format CHE-123.456.789',
        businessIdentifierRegex: '^(?:CHE[-.\\s]?)?\\d{3}[-.\\s]?\\d{3}[-.\\s]?\\d{3}(?:\\s?(?:TVA|MWST|IVA))?$',
        businessIdentifierFormatPlaceholder: 'CHE-849.204.892 TVA',
        vatNumberFormatPlaceholder: 'CHE-849.204.892 TVA',
        vatNumberRegex: '^(?:CHE[-.\\s]?)?\\d{3}[-.\\s]?\\d{3}[-.\\s]?\\d{3}(?:\\s?(?:TVA|MWST|IVA))?$',
        supportedLegalForms: [
          'Raison individuelle (Indépendant)',
          'Sàrl (Société à responsabilité limitée)',
          'SA (Société Anonyme)',
          'Société en nom collectif',
          'Association',
        ],
        requiredVerificationDocuments: [
          {
            id: 'rc_extract',
            label: 'Extrait du Registre du Commerce (RC)',
            description: 'Extrait certifié conforme récent',
          },
        ],
      },
    },
    createdAt: '2024-03-01T00:00:00Z',
    updatedAt: '2026-08-16T22:00:00Z',
    version: 1,
  },

  // 5. LUXEMBOURG (Active - EUR, VAT 17%, RCS Luxembourg)
  {
    id: 'market-lu',
    code: 'LU',
    countryCode: 'LU',
    name: 'Luxembourg',
    flag: '🇱🇺',
    status: 'active',
    isDefault: false,
    defaultLocale: 'fr-LU',
    supportedLocales: ['fr-LU', 'de-LU', 'lb-LU', 'en-US'],
    currency: 'EUR',
    currencySymbol: '€',
    timezone: 'Europe/Luxembourg',
    geography: {
      allCountryEnabled: true,
      regions: [
        {
          name: 'Canton de Luxembourg',
          code: 'LUX',
          cities: [
            { name: 'Luxembourg-Ville', postalCode: 'L-1110', region: 'Luxembourg', isPopular: true },
            { name: 'Strassen', postalCode: 'L-8001', region: 'Luxembourg' },
            { name: 'Hesperange', postalCode: 'L-5801', region: 'Luxembourg' },
          ],
        },
        {
          name: 'Canton d\'Esch-sur-Alzette',
          code: 'ESC',
          cities: [
            { name: 'Esch-sur-Alzette', postalCode: 'L-4001', region: 'Esch-sur-Alzette', isPopular: true },
            { name: 'Differdange', postalCode: 'L-4501', region: 'Esch-sur-Alzette' },
            { name: 'Dudelange', postalCode: 'L-3401', region: 'Esch-sur-Alzette' },
          ],
        },
      ],
      popularCities: [
        { name: 'Luxembourg-Ville', postalCode: 'L-1110', region: 'Luxembourg' },
        { name: 'Esch-sur-Alzette', postalCode: 'L-4001', region: 'Esch-sur-Alzette' },
        { name: 'Differdange', postalCode: 'L-4501', region: 'Esch-sur-Alzette' },
        { name: 'Dudelange', postalCode: 'L-3401', region: 'Esch-sur-Alzette' },
      ],
    },
    overrides: {
      general: {
        name: 'Grand-Duché de Luxembourg',
        supportEmail: 'support@shongre.lu',
      },
      localization: {
        defaultLocale: 'fr-LU',
        supportedLocales: ['fr-LU', 'de-LU', 'lb-LU', 'en-US'],
        phonePrefix: '+352',
        phonePlaceholder: '621 123 456',
        phoneRegex: '^(?:(?:\\+|00)352)?[2-9]\\d{5,8}$',
        postalCodePlaceholder: 'L-1110',
        postalCodeRegex: '^(?:L-)?\\d{4}$',
      },
      taxes: {
        vatRateStandard: 0.17, // 17% Luxembourg VAT
      },
      pro: {
        businessIdentifierLabel: 'Numéro RCS Luxembourg',
        businessIdentifierHelper: 'Format B123456 ou matricule national',
        businessIdentifierRegex: '^(?:[A-Z]\\s?\\d{4,7}|\\d{11})$',
        businessIdentifierFormatPlaceholder: 'B 123456',
        vatNumberFormatPlaceholder: 'LU 12345678',
        vatNumberRegex: '^LU\\s?[0-9]{8}$',
        supportedLegalForms: [
          'Indépendant / Personne physique',
          'SARL (Société à responsabilité limitée)',
          'SARL-S (SARL simplifiée)',
          'SA (Société Anonyme)',
          'SENC (Société en nom collectif)',
          'ASBL',
        ],
        requiredVerificationDocuments: [
          {
            id: 'rcs_extract',
            label: 'Extrait du Registre de Commerce et des Sociétés (RCS)',
            description: 'Extrait certifié du LBR récent',
          },
        ],
      },
    },
    createdAt: '2024-06-01T00:00:00Z',
    updatedAt: '2026-08-16T22:00:00Z',
    version: 1,
  },
];
